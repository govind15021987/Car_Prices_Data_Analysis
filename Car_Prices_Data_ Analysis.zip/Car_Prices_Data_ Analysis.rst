.. code:: ipython3

    import pandas as pd
    #Read the CSV file
    car_df = pd.read_csv('car_prices.csv')

.. code:: ipython3

    #Display the first 5 rows
    car_df.head()




.. raw:: html

    <div>
    <style scoped>
        .dataframe tbody tr th:only-of-type {
            vertical-align: middle;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    
        .dataframe thead th {
            text-align: right;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>year</th>
          <th>make</th>
          <th>model</th>
          <th>trim</th>
          <th>body</th>
          <th>transmission</th>
          <th>vin</th>
          <th>state</th>
          <th>condition</th>
          <th>odometer</th>
          <th>color</th>
          <th>interior</th>
          <th>seller</th>
          <th>mmr</th>
          <th>sellingprice</th>
          <th>saledate</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th>0</th>
          <td>2015</td>
          <td>Kia</td>
          <td>Sorento</td>
          <td>LX</td>
          <td>SUV</td>
          <td>automatic</td>
          <td>5xyktca69fg566472</td>
          <td>ca</td>
          <td>5.0</td>
          <td>16639.0</td>
          <td>white</td>
          <td>black</td>
          <td>kia motors america  inc</td>
          <td>20500.0</td>
          <td>21500.0</td>
          <td>Tue Dec 16 2014 12:30:00 GMT-0800 (PST)</td>
        </tr>
        <tr>
          <th>1</th>
          <td>2015</td>
          <td>Kia</td>
          <td>Sorento</td>
          <td>LX</td>
          <td>SUV</td>
          <td>automatic</td>
          <td>5xyktca69fg561319</td>
          <td>ca</td>
          <td>5.0</td>
          <td>9393.0</td>
          <td>white</td>
          <td>beige</td>
          <td>kia motors america  inc</td>
          <td>20800.0</td>
          <td>21500.0</td>
          <td>Tue Dec 16 2014 12:30:00 GMT-0800 (PST)</td>
        </tr>
        <tr>
          <th>2</th>
          <td>2014</td>
          <td>BMW</td>
          <td>3 Series</td>
          <td>328i SULEV</td>
          <td>Sedan</td>
          <td>automatic</td>
          <td>wba3c1c51ek116351</td>
          <td>ca</td>
          <td>45.0</td>
          <td>1331.0</td>
          <td>gray</td>
          <td>black</td>
          <td>financial services remarketing (lease)</td>
          <td>31900.0</td>
          <td>30000.0</td>
          <td>Thu Jan 15 2015 04:30:00 GMT-0800 (PST)</td>
        </tr>
        <tr>
          <th>3</th>
          <td>2015</td>
          <td>Volvo</td>
          <td>S60</td>
          <td>T5</td>
          <td>Sedan</td>
          <td>automatic</td>
          <td>yv1612tb4f1310987</td>
          <td>ca</td>
          <td>41.0</td>
          <td>14282.0</td>
          <td>white</td>
          <td>black</td>
          <td>volvo na rep/world omni</td>
          <td>27500.0</td>
          <td>27750.0</td>
          <td>Thu Jan 29 2015 04:30:00 GMT-0800 (PST)</td>
        </tr>
        <tr>
          <th>4</th>
          <td>2014</td>
          <td>BMW</td>
          <td>6 Series Gran Coupe</td>
          <td>650i</td>
          <td>Sedan</td>
          <td>automatic</td>
          <td>wba6b2c57ed129731</td>
          <td>ca</td>
          <td>43.0</td>
          <td>2641.0</td>
          <td>gray</td>
          <td>black</td>
          <td>financial services remarketing (lease)</td>
          <td>66000.0</td>
          <td>67000.0</td>
          <td>Thu Dec 18 2014 12:30:00 GMT-0800 (PST)</td>
        </tr>
      </tbody>
    </table>
    </div>



.. code:: ipython3

    # Display data types and record count
    car_df.info()


.. parsed-literal::

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 558837 entries, 0 to 558836
    Data columns (total 16 columns):
     #   Column        Non-Null Count   Dtype  
    ---  ------        --------------   -----  
     0   year          558837 non-null  int64  
     1   make          548536 non-null  object 
     2   model         548438 non-null  object 
     3   trim          548186 non-null  object 
     4   body          545642 non-null  object 
     5   transmission  493485 non-null  object 
     6   vin           558833 non-null  object 
     7   state         558837 non-null  object 
     8   condition     547017 non-null  float64
     9   odometer      558743 non-null  float64
     10  color         558088 non-null  object 
     11  interior      558088 non-null  object 
     12  seller        558837 non-null  object 
     13  mmr           558799 non-null  float64
     14  sellingprice  558825 non-null  float64
     15  saledate      558825 non-null  object 
    dtypes: float64(4), int64(1), object(11)
    memory usage: 68.2+ MB
    

.. code:: ipython3

    #Understanding the Data Structure
    #Check the shape of the dataset (rows and columns)
    car_df.shape




.. parsed-literal::

    (558837, 16)



.. code:: ipython3

    #Display column names and data types
    car_df.columns




.. parsed-literal::

    Index(['year', 'make', 'model', 'trim', 'body', 'transmission', 'vin', 'state',
           'condition', 'odometer', 'color', 'interior', 'seller', 'mmr',
           'sellingprice', 'saledate'],
          dtype='object')



.. code:: ipython3

    car_df.dtypes




.. parsed-literal::

    year              int64
    make             object
    model            object
    trim             object
    body             object
    transmission     object
    vin              object
    state            object
    condition       float64
    odometer        float64
    color            object
    interior         object
    seller           object
    mmr             float64
    sellingprice    float64
    saledate         object
    dtype: object



.. code:: ipython3

    # Count null values in each column
    null_values = car_df.isnull().sum()
    
    # Display null values
    print(null_values)


.. parsed-literal::

    year                0
    make            10301
    model           10399
    trim            10651
    body            13195
    transmission    65352
    vin                 4
    state               0
    condition       11820
    odometer           94
    color             749
    interior          749
    seller              0
    mmr                38
    sellingprice       12
    saledate           12
    dtype: int64
    

.. code:: ipython3

    import matplotlib.pyplot as plt
    # Store null counts
    null_values = car_df.isnull().sum()
    # Keep only columns having null values
    null_values = null_values[null_values > 0]

.. code:: ipython3

    # Plot bar chart
    plt.figure(figsize=(10,5))
    null_values.plot(kind='bar')
    # Add title and labels
    plt.title('Null Values Per Column')
    plt.xlabel('Columns')
    plt.ylabel('Number of Null Values')




.. parsed-literal::

    Text(0, 0.5, 'Number of Null Values')




.. image:: output_8_1.png


